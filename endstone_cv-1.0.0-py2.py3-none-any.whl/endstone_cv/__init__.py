from .Entry import Entry

__all__ = ["Entry"]
