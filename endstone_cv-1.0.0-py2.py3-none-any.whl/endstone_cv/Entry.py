from endstone.plugin import Plugin
from endstone import Player
from endstone.scheduler import Task
from binarystream import BinaryStream
from endstone.command import Command, CommandSender
import typing
import os
import re
import json


class Entry(Plugin):
  api_version = "0.4"

  commands = {
    "spawn": {
      "description": "Телепортация на спавн.",
      "usages": ["/spawn"],
      "permissions": ["Entry.command.spawn"]
    }
  }

  permissions = {
    "Entry.command.spawn": {
      "description": "Allow users to use the /spawn command.",
      "default": "op"
    }
  }

  def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
    if command.name == "spawn":
      sender.send_message("Не воркает")
    return True

  def callback(self) -> None:
    for target in self.server.online_players:
      bs = BinaryStream()

  def on_enable(self) -> None:
    self.task = self.server.scheduler.run_task(self, self.callback, 0, 1)

  def on_disable(self) -> None:
    typing.cast(None, self.task and self.task.cancel())
