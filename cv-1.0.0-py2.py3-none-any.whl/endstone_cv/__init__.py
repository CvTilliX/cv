from endstone_cv.Entry import Entry

__all__ = ["Entry"]
